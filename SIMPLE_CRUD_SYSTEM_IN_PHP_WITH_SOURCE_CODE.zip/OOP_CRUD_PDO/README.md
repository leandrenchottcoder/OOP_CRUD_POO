# OOP_CRUD_PDO
A simple Project of CRUD operation using PDO(php data object) in OOP style





### Database name : oop_pdo_crud

### Table name: student




