</div>

  <footer class="footeroption">
	  <section class="footerone">
	  <p>Ahammed Imtiaze</p>
	  <p>PHP developer</p>
	  <p>################</p>
	  
	  </section>
	  <section class="footerone">
		  <p>##########</p>
		  <p>FB : # </p>
		  <p>Web: #</p>
	  </section>
  </footer>

</body>
</html>
